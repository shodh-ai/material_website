Beyond Reconstruction Error
A4 manuscript edition based on the supplied layout reference.

Compile from this directory with Tectonic (uses XeTeX):
  tectonic beyond_reconstruction_error.tex

Keep the figures directory next to the manuscript source.
The source uses TeX Gyre Termes and TeX Gyre Termes Math.
All references are embedded in the manuscript source.
