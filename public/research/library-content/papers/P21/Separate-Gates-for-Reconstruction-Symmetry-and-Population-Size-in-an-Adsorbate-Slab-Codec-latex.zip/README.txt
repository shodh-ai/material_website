Separate Gates for Reconstruction, Symmetry and Population Size in an Adsorbate–Slab Codec

PDF-derived LaTeX package

Extract the ZIP, then run tectonic main.tex or xelatex main.tex.
The editable source follows the published PDF's extracted text.
Use the published PDF for the exact equations, tables, and figures.

Published PDF: https://shodh.ai/research/papers/P21/Separate-Gates-for-Reconstruction-Symmetry-and-Population-Size-in-an-Adsorbate-Slab-Codec.pdf
PDF SHA-256: debccb06de0ca5c38ee3465448669b7b18de51128f8dc6c045d20caa9931a2a4
