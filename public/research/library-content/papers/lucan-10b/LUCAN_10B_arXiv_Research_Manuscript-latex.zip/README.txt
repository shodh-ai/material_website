LUCAN-10B-Physics: A Sparse Foundation Model for Cross-Scale Physical Prediction

PDF-derived LaTeX package

Extract the ZIP, then run tectonic main.tex or xelatex main.tex.
The editable source follows the published PDF's extracted text.
Use the published PDF for the exact equations, tables, and figures.

Published PDF: https://shodh.ai/research/papers/lucan-10b/LUCAN_10B_arXiv_Research_Manuscript.pdf
PDF SHA-256: aa9dbe505497589c704154058617bb684e6ee875e84a053b6e87760fffbaed89
