Toward pose-robust, residue-faithful antibody tokenization: Stored-byte diagnostics and a framework-anchored design

PDF-derived LaTeX package

Extract the ZIP, then run tectonic main.tex or xelatex main.tex.
The editable source follows the published PDF's extracted text.
Use the published PDF for the exact equations, tables, and figures.

Published PDF: https://shodh.ai/research/papers/P03/Toward-pose-robust-residue-faithful-antibody-tokenization-Stored-byte-diagnostics-and-a-framework-anchored-design.pdf
PDF SHA-256: 390a9ae9f99e138ab45af5d766ff67a09d77a46b6a6793f08b2796ef513003cf
