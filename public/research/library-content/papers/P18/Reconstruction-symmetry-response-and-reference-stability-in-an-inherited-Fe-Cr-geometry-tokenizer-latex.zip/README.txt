Reconstruction, symmetry response, and reference stability in an inherited Fe–Cr geometry tokenizer

PDF-derived LaTeX package

Extract the ZIP, then run tectonic main.tex or xelatex main.tex.
The editable source follows the published PDF's extracted text.
Use the published PDF for the exact equations, tables, and figures.

Published PDF: https://shodh.ai/research/papers/P18/Reconstruction-symmetry-response-and-reference-stability-in-an-inherited-Fe-Cr-geometry-tokenizer.pdf
PDF SHA-256: f05e4038ea58b5c4b60fc077aced4e7842926f42b91f21c251139aefca29c1b6
