Discrete Constraints, Harmonic Modes, and Reconstruction Fidelity in Periodic Fluid and Magnetic Autoencoders

PDF-derived LaTeX package

Extract the ZIP, then run tectonic main.tex or xelatex main.tex.
The editable source follows the published PDF's extracted text.
Use the published PDF for the exact equations, tables, and figures.

Published PDF: https://shodh.ai/research/papers/P14/Discrete-Constraints-Harmonic-Modes-and-Reconstruction-Fidelity-in-Periodic-Fluid-and-Magnetic-Autoencoders.pdf
PDF SHA-256: ebb9464aba4e7ff7e0b83df8e7d7d07a404f61c05bacc7019ac04bce9f037a75
