Rotation sensitivity after BF16 storage in coarse-grained molecular encoding and a conditional pocket-frame correction

PDF-derived LaTeX package

Extract the ZIP, then run tectonic main.tex or xelatex main.tex.
The editable source follows the published PDF's extracted text.
Use the published PDF for the exact equations, tables, and figures.

Published PDF: https://shodh.ai/research/papers/P04/Rotation-sensitivity-after-BF16-storage-in-coarse-grained-molecular-encoding-and-a-conditional-pocket-frame-correction.pdf
PDF SHA-256: 1054c68a9321f9760ff49782e8751cd18fc122ab81fa2dfce9cf925595726d37
