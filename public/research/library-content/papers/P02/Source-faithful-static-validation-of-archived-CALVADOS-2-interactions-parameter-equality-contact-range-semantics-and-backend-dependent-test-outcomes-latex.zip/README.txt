Source-faithful static validation of archived CALVADOS-2 interactions: parameter equality, contact-range semantics, and backend-dependent test outcomes

PDF-derived LaTeX package

Extract the ZIP, then run tectonic main.tex or xelatex main.tex.
The editable source follows the published PDF's extracted text.
Use the published PDF for the exact equations, tables, and figures.

Published PDF: https://shodh.ai/research/papers/P02/Source-faithful-static-validation-of-archived-CALVADOS-2-interactions-parameter-equality-contact-range-semantics-and-backend-dependent-test-outcomes.pdf
PDF SHA-256: e0f88fa10165439149dd45d41b8adbbfe35afd7d90027137cb2c7f1ef0248e63
