Peak and Spectral Agreement Do Not Establish Field Reconstruction

PDF-derived LaTeX package

Extract the ZIP, then run tectonic main.tex or xelatex main.tex.
The editable source follows the published PDF's extracted text.
Use the published PDF for the exact equations, tables, and figures.

Published PDF: https://shodh.ai/research/papers/P15/Peak-and-Spectral-Agreement-Do-Not-Establish-Field-Reconstruction.pdf
PDF SHA-256: 687e1c0c5a222b27674ccdd249dca3de88bf446a262946dc9ee70085e195e3f0
