Contraction-precision sensitivity in a coupled D3Q19 rheology–particulate workflow

PDF-derived LaTeX package

Extract the ZIP, then run tectonic main.tex or xelatex main.tex.
The editable source follows the published PDF's extracted text.
Use the published PDF for the exact equations, tables, and figures.

Published PDF: https://shodh.ai/research/papers/P09/Contraction-precision-sensitivity-in-a-coupled-D3Q19-rheology-particulate-workflow.pdf
PDF SHA-256: 3015fdb73f33ddac1c5b999d498504f8b5da17f247cad15ee64a4a250e386e1b
