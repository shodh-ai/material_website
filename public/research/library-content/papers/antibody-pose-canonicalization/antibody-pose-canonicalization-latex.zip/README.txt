Rotation dependence in an antibody structure tokenizer and sequence-anchored canonicalization

PDF-derived LaTeX package

Extract the ZIP, then run tectonic main.tex or xelatex main.tex.
The editable source follows the published PDF's extracted text.
Use the published PDF for the exact equations, tables, and figures.

Published PDF: https://shodh.ai/blog/antibody-tokenizer-rotation-invariance/antibody-tokenizer-pose-dependence.pdf
PDF SHA-256: 674e3165124f54afabda9ca8ed105c30e6630b7fe2af16c529cb89699a842386
