Stored-Byte Distinctness and Physical Population Accounting in Scientific Latent Datasets

PDF-derived LaTeX package

Extract the ZIP, then run tectonic main.tex or xelatex main.tex.
The editable source follows the published PDF's extracted text.
Use the published PDF for the exact equations, tables, and figures.

Published PDF: https://shodh.ai/research/papers/P25/Stored-Byte-Distinctness-and-Physical-Population-Accounting-in-Scientific-Latent-Datasets.pdf
PDF SHA-256: 101d7dc4f8aaca7c3c14d0e360d6a6e3bab53b883cccee61eef4fad47ffb8187
