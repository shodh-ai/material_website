Grid-native latent patchification for two-dimensional Maxwell-field reconstruction: a checkpoint-selection-aware retrospective case study

PDF-derived LaTeX package

Extract the ZIP, then run tectonic main.tex or xelatex main.tex.
The editable source follows the published PDF's extracted text.
Use the published PDF for the exact equations, tables, and figures.

Published PDF: https://shodh.ai/research/papers/P12/Grid-native-latent-patchification-for-two-dimensional-Maxwell-field-reconstruction-a-checkpoint-selection-aware-retrospective-case-study.pdf
PDF SHA-256: 251c871a596ecc98286c82ad63235596a9ab91eb9f2d95ff6a4903cf2f1ad1a0
