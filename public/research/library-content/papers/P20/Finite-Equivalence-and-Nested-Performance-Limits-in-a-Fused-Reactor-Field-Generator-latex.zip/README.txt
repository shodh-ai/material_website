Finite Equivalence and Nested Performance Limits in a Fused Reactor-Field Generator

PDF-derived LaTeX package

Extract the ZIP, then run tectonic main.tex or xelatex main.tex.
The editable source follows the published PDF's extracted text.
Use the published PDF for the exact equations, tables, and figures.

Published PDF: https://shodh.ai/research/papers/P20/Finite-Equivalence-and-Nested-Performance-Limits-in-a-Fused-Reactor-Field-Generator.pdf
PDF SHA-256: dae11ba9b0d07d8fc654004e1d8b048bb5cc865a6a960cdc8fd7ef80c6b1432e
