What Passing Solver Checks Establish: Periodic Decay, Manufactured Pressure, and Failed Boundary Response in Fluid Verification

PDF-derived LaTeX package

Extract the ZIP, then run tectonic main.tex or xelatex main.tex.
The editable source follows the published PDF's extracted text.
Use the published PDF for the exact equations, tables, and figures.

Published PDF: https://shodh.ai/research/papers/P13/What-Passing-Solver-Checks-Establish-Periodic-Decay-Manufactured-Pressure-and-Failed-Boundary-Response-in-Fluid-Verification.pdf
PDF SHA-256: a350ed15bef5a283c34f37716ba1c3a9582ec1cffb622f4e7d4a65bfb21c1dd5
