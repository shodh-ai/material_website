Energy Balance and Comparison Observables in a PMMA Impact-Fracture Simulation Audit

PDF-derived LaTeX package

Extract the ZIP, then run tectonic main.tex or xelatex main.tex.
The editable source follows the published PDF's extracted text.
Use the published PDF for the exact equations, tables, and figures.

Published PDF: https://shodh.ai/research/papers/P16/Energy-Balance-and-Comparison-Observables-in-a-PMMA-Impact-Fracture-Simulation-Audit.pdf
PDF SHA-256: 98b5b27331cf697b5f4253aea7e37ce27848d98dc658aede7be38f1dc55983fd
