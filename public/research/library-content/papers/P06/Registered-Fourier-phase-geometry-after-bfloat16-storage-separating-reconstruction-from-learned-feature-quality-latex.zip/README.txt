Registered Fourier-phase geometry after bfloat16 storage: separating reconstruction from learned feature quality

PDF-derived LaTeX package

Extract the ZIP, then run tectonic main.tex or xelatex main.tex.
The editable source follows the published PDF's extracted text.
Use the published PDF for the exact equations, tables, and figures.

Published PDF: https://shodh.ai/research/papers/P06/Registered-Fourier-phase-geometry-after-bfloat16-storage-separating-reconstruction-from-learned-feature-quality.pdf
PDF SHA-256: 5bc95400c1d90fd135fe26c8fba779b6f1933477130b631525c8d8b5757e670a
